package org.apache.uima.resource.metadata.impl;

import java.io.IOException;
import java.net.URL;
import java.util.*;

import org.xml.sax.SAXException;// ★新增
import org.xml.sax.ContentHandler;// ★新增
import org.apache.uima.UIMAFramework;
import org.apache.uima.UIMA_IllegalArgumentException;
import org.apache.uima.UIMARuntimeException; // ★新增
import org.apache.uima.resource.ResourceManager;
import org.apache.uima.resource.metadata.Import;
import org.apache.uima.resource.metadata.TypeDescription;
import org.apache.uima.resource.metadata.TypeSystemDescription;
import org.apache.uima.util.InvalidXMLException;
import org.apache.uima.util.XMLInputSource;
import org.apache.uima.util.XMLParser;           // ★新增
import org.apache.uima.util.XMLizable;
import org.w3c.dom.Element;                     // ★新增

public class TypeSystemDescription_impl extends MetaDataObject_impl implements TypeSystemDescription {
    static final long serialVersionUID = -3372766232454730201L;
    private String mName;
    private String mVersion;
    private String mDescription;
    private String mVendor;
    private Import[] mImports;
    private TypeDescription[] mTypes;

    public TypeSystemDescription_impl() {
        this.mImports = Import.EMPTY_IMPORTS;
        this.mTypes = new TypeDescription[0];
    }

    @Override
    public String getName() { return this.mName; }

    @Override
    public void setName(String aName) { this.mName = aName; }

    @Override
    public String getVersion() { return this.mVersion; }

    @Override
    public void setVersion(String aVersion) { this.mVersion = aVersion; }

    @Override
    public String getDescription() { return this.mDescription; }

    @Override
    public void setDescription(String aDescription) { this.mDescription = aDescription; }

    @Override
    public String getVendor() { return this.mVendor; }

    @Override
    public void setVendor(String aVendor) { this.mVendor = aVendor; }

    @Override
    public Import[] getImports() { return this.mImports; }

    @Override
    public void setImports(Import[] aImports) {
        if (aImports == null) {
            throw new UIMA_IllegalArgumentException("illegal_argument",
                    new Object[]{"null", "aImports", "setImports"});
        } else {
            this.mImports = aImports;
        }
    }

    @Override
    public TypeDescription[] getTypes() { return this.mTypes; }

    @Override
    public void setTypes(TypeDescription[] aTypes) {
        if (aTypes == null) {
            throw new UIMA_IllegalArgumentException("illegal_argument",
                    new Object[]{"null", "aTypes", "setTypes"});
        } else {
            this.mTypes = aTypes;
        }
    }

    @Override
    public TypeDescription addType(String aTypeName, String aDescription, String aSupertypeName) {
        TypeDescription newType = new TypeDescription_impl(aTypeName, aDescription, aSupertypeName);
        TypeDescription[] types = this.getTypes();
        if (types == null) {
            this.setTypes(new TypeDescription[]{newType});
        } else {
            TypeDescription[] newArray = Arrays.copyOf(types, types.length + 1);
            newArray[types.length] = newType;
            this.setTypes(newArray);
        }
        return newType;
    }

    @Override
    public TypeDescription getType(String aTypeName) {
        for (TypeDescription td : this.mTypes) {
            if (aTypeName.equals(td.getName())) {
                return td;
            }
        }
        return null;
    }

    @Override
    public synchronized void resolveImports() throws InvalidXMLException {
        if (this.getImports().length == 0) {
            this.resolveImports((Collection<String>) null, null);
        } else {
            this.resolveImports(new TreeSet<String>(), UIMAFramework.newDefaultResourceManager());
        }
    }

    @Override
    public synchronized void resolveImports(ResourceManager aResourceManager) throws InvalidXMLException {
        this.resolveImports(this.getImports().length == 0 ? null : new TreeSet<String>(), aResourceManager);
    }

    @Override
    public synchronized void resolveImports(Collection<String> aAlreadyImportedTypeSystemURLs,
                                            ResourceManager aResourceManager) throws InvalidXMLException {
        List<TypeDescription> importedTypes = null;
        if (this.getImports().length != 0) {
            if (this.getSourceUrl() != null && aAlreadyImportedTypeSystemURLs != null) {
                aAlreadyImportedTypeSystemURLs.add(this.getSourceUrl().toString());
            }
            importedTypes = new ArrayList<>();
            Import[] imports = this.getImports();
            for (Import imp : imports) {
                if (imp instanceof Import_impl) {
                    ((Import_impl) imp).setSourceUrlIfNull(this.getSourceUrl());
                }
                URL url = imp.findAbsoluteUrl(aResourceManager);
                if (aAlreadyImportedTypeSystemURLs == null || !aAlreadyImportedTypeSystemURLs.contains(url.toString())) {
                    if (aAlreadyImportedTypeSystemURLs != null) {
                        aAlreadyImportedTypeSystemURLs.add(url.toString());
                    }
                    try {
                        this.resolveImport(url, aAlreadyImportedTypeSystemURLs, importedTypes, aResourceManager);
                    } catch (IOException e) {
                        throw new InvalidXMLException("import_failed_could_not_read_from_url",
                                new Object[]{url, imp.getSourceUrlString()}, e);
                    }
                }
            }
        }
        TypeDescription[] existingTypes = this.getTypes();
        if (existingTypes == null) {
            this.setTypes(TypeDescription.EMPTY_TYPE_DESCRIPTIONS);
            existingTypes = this.getTypes();
        }
        if (importedTypes != null) {
            TypeDescription[] newTypes = Arrays.copyOf(existingTypes, existingTypes.length + importedTypes.size());
            for (int i = 0; i < importedTypes.size(); i++) {
                newTypes[existingTypes.length + i] = importedTypes.get(i);
            }
            this.setTypes(newTypes);
        }
        this.setImports(Import.EMPTY_IMPORTS);
    }

    private void resolveImport(URL aURL, Collection<String> aAlreadyImportedTypeSystemURLs,
                               Collection<TypeDescription> aResults,
                               ResourceManager aResourceManager) throws InvalidXMLException, IOException {
        String urlString = aURL.toString();
        Map<String, XMLizable> importCache = aResourceManager.getImportCache();
        TypeSystemDescription desc;
        synchronized (importCache) {
            XMLizable cachedObject = importCache.get(urlString);
            if (cachedObject instanceof TypeSystemDescription) {
                desc = (TypeSystemDescription) cachedObject;
            } else {
                XMLInputSource input = new XMLInputSource(aURL);
                desc = UIMAFramework.getXMLParser().parseTypeSystemDescription(input);
                desc.resolveImports(aAlreadyImportedTypeSystemURLs, aResourceManager);
                importCache.put(urlString, desc);
            }
        }
        aResults.addAll(Arrays.asList(desc.getTypes()));
    }

    // ------------------------------- ★新增 实现抽象方法 -------------------------------

    /** 1. 返回 XML 化元信息（根标签、命名空间、属性列表） */
    @Override
    protected XmlizationInfo getXmlizationInfo() {
        return new XmlizationInfo(
                "typeSystemDescription",
                null,
                new PropertyXmlInfo[] {
                        new PropertyXmlInfo("name", false, null),
                        new PropertyXmlInfo("description", false, null),
                        new PropertyXmlInfo("version", false, null),
                        new PropertyXmlInfo("vendor", false, null),
                        new PropertyXmlInfo("imports", true, Import_impl.class),
                        new PropertyXmlInfo("types", true, TypeDescription_impl.class)
                }
        );
    }

    /** 2. 实现接口的 getAttributeValue(String) */
    @Override
    public Object getAttributeValue(String aName) {
        for (MetaDataAttr attr : getAttributes()) {
            if (attr.name.equals(aName) && attr.reader != null) {
                try {
                    return attr.reader.invoke(this);
                } catch (Exception e) {
                    throw new UIMARuntimeException(e);
                }
            }
        }
        return null;
    }

    /** 3. 实现接口的 setAttributeValue(String,Object) */
    @Override
    public void setAttributeValue(String aName, Object aValue) {
        for (MetaDataAttr attr : getAttributes()) {
            if (attr.name.equals(aName) && attr.writer != null) {
                try {
                    attr.writer.invoke(this, aValue);
                    return;
                } catch (IllegalArgumentException e) {
                    throw new UIMA_IllegalArgumentException("metadata_attribute_type_mismatch",
                            new Object[]{aValue, attr.name}, e);
                } catch (Exception e) {
                    throw new UIMARuntimeException(e);
                }
            }
        }
        // 修复 ② 用参数形式构造
        throw new UIMA_IllegalArgumentException("illegal_argument",
                new Object[]{"No such attribute: " + aName});
    }

    /** 4. 实现 XMLizable 新接口方法 */
    @Override
    public void buildFromXMLElement(Element elem, XMLParser parser, XMLParser.ParsingOptions options)
            throws InvalidXMLException {
        // 没有 lenient 字段的安全写法
        buildFromXMLElement(elem, parser, false);
    }


    @Override
    public void buildFromXMLElement(Element elem, XMLParser parser) throws InvalidXMLException {
        // 调用你的已有实现，默认非宽松模式
        buildFromXMLElement(elem, parser, false);
    }

    @Override
    public void toXML(ContentHandler ch) throws SAXException {
        toXML(ch, true); // 默认带 namespace 属性
    }

}