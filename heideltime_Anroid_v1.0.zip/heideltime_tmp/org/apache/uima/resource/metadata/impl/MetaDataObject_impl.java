package org.apache.uima.resource.metadata.impl;

import org.apache.uima.UIMARuntimeException;
import org.apache.uima.UIMA_IllegalArgumentException;
import org.apache.uima.UIMA_UnsupportedOperationException;
import org.apache.uima.internal.util.XMLUtils;
import org.apache.uima.resource.metadata.AllowedValue;
import org.apache.uima.resource.metadata.MetaDataObject;
import org.apache.uima.util.ConcurrentHashMapWithProducer;
import org.apache.uima.util.InvalidXMLException;
import org.apache.uima.util.NameClassPair;
import org.apache.uima.util.XMLParser;
import org.apache.uima.util.XMLSerializer;
import org.apache.uima.util.XMLizable;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.reflect.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/**
 * Android-compatible MetaDataObject_impl
 * Removes java.beans.Introspector dependency, uses reflection instead.
 */
public abstract class MetaDataObject_impl implements MetaDataObject, Cloneable {

    static final long serialVersionUID = 5876728533863334480L;
    private static final String PROP_NAME_SOURCE_URL = "sourceUrl";
    private static final String PROP_NAME_INFOSET = "infoset";
    private static final Attributes EMPTY_ATTRIBUTES = new AttributesImpl();
    private static final List<MetaDataAttr> EMPTY_ATTRIBUTE_LIST = Collections.emptyList();
    private static final transient ConcurrentHashMapWithProducer<Class<? extends MetaDataObject_impl>, MetaDataAttr[]> class2attrsMap = new ConcurrentHashMapWithProducer();
    private static final transient ConcurrentHashMapWithProducer<Class<? extends MetaDataObject_impl>, MetaDataAttr[]> class2attrsMapUnfiltered = new ConcurrentHashMapWithProducer();
    public static final ThreadLocal<SerialContext> serialContext = new ThreadLocal();
    private transient URL mSourceUrl;
    private transient Node infoset = null;

    // ======= Android 兼容 Getter/Setter 扫描实现（替代 java.beans.Introspector） =======
    private void getAttributesFromBeans(Class<? extends MetaDataObject_impl> clazz) {
        Map<String, Method> getters = new HashMap<>();
        Map<String, Method> setters = new HashMap<>();

        for (Method m : clazz.getMethods()) {
            if (Modifier.isPublic(m.getModifiers()) && !Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
                String name = m.getName();
                if (name.startsWith("get") && name.length() > 3 && !name.equals("getClass")) {
                    String prop = decapitalize(name.substring(3));
                    getters.put(prop, m);
                } else if (name.startsWith("is") && name.length() > 2 && (m.getReturnType() == boolean.class || m.getReturnType() == Boolean.class)) {
                    String prop = decapitalize(name.substring(2));
                    getters.put(prop, m);
                }
            } else if (Modifier.isPublic(m.getModifiers()) && !Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 1) {
                String name = m.getName();
                if (name.startsWith("set") && name.length() > 3) {
                    String prop = decapitalize(name.substring(3));
                    setters.put(prop, m);
                }
            }
        }

        // 构造属性列表
        List<MetaDataAttr> filtered = new ArrayList<>();
        List<MetaDataAttr> unfiltered = new ArrayList<>();
        for (Map.Entry<String, Method> e : getters.entrySet()) {
            String propName = e.getKey();
            Method getter = e.getValue();
            Method setter = setters.get(propName);
            Class<?> propType = getter.getReturnType();
            if (propType.isPrimitive()) {
                propType = getWrapperClass(propType);
            }
            MetaDataAttr mda = new MetaDataAttr(propName, getter, setter, propType);
            unfiltered.add(mda);
            if (setter != null &&
                    !PROP_NAME_SOURCE_URL.equals(propName) &&
                    !PROP_NAME_INFOSET.equals(propName)) {
                filtered.add(mda);
            }
        }

        filtered.addAll(getAdditionalAttributes());
        unfiltered.addAll(getAdditionalAttributes());

        class2attrsMap.putIfAbsent(clazz, filtered.toArray(new MetaDataAttr[0]));
        class2attrsMapUnfiltered.putIfAbsent(clazz, unfiltered.toArray(new MetaDataAttr[0]));
    }

    private String decapitalize(String s) {
        if (s.length() == 0) return s;
        return Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }

    // ------------- 以下保留原版所有逻辑（略去注释，基本一致） -------------

    public static SerialContext getSerialContext(ContentHandler ch) {
        SerialContext sc = serialContext.get();
        if (null == sc) {
            sc = new SerialContext(ch, getSerializerFromContentHandler(ch));
            serialContext.set(sc);
        }
        return sc;
    }

    public void setInfoset(Node infoset) { this.infoset = infoset; }
    public Node getInfoset() { return this.infoset; }
    public List<MetaDataAttr> getAdditionalAttributes() { return EMPTY_ATTRIBUTE_LIST; }

    MetaDataAttr[] getUnfilteredAttributes() {
        Class<? extends MetaDataObject_impl> clazz = this.getClass();
        MetaDataAttr[] attrs = class2attrsMapUnfiltered.get(clazz);
        if (attrs == null) getAttributesFromBeans(clazz);
        return class2attrsMapUnfiltered.get(clazz);
    }

    MetaDataAttr[] getAttributes() {
        Class<? extends MetaDataObject_impl> clazz = this.getClass();
        MetaDataAttr[] attrs = class2attrsMap.get(clazz);
        if (attrs == null) getAttributesFromBeans(clazz);
        return class2attrsMap.get(clazz);
    }

    protected static Class<?> getWrapperClass(Class<?> aPrimitiveType) {
        if (Integer.TYPE.equals(aPrimitiveType)) return Integer.class;
        if (Short.TYPE.equals(aPrimitiveType)) return Short.class;
        if (Long.TYPE.equals(aPrimitiveType)) return Long.class;
        if (Byte.TYPE.equals(aPrimitiveType)) return Byte.class;
        if (Character.TYPE.equals(aPrimitiveType)) return Character.class;
        if (Float.TYPE.equals(aPrimitiveType)) return Float.class;
        if (Double.TYPE.equals(aPrimitiveType)) return Double.class;
        if (Boolean.TYPE.equals(aPrimitiveType)) return Boolean.class;
        return aPrimitiveType;
    }
    /**
     * 从 ContentHandler 中递归查找 Serializer
     * 支持被 XMLFilterImpl 或其它包装类多层包裹的情况
     */
    private static Serializer getSerializerFromContentHandler(ContentHandler ch) {
        if (ch == null) {
            throw new UIMARuntimeException(
                    new IllegalArgumentException("ContentHandler is null"));
        }

        // 直接就是 Serializer（例如 XMLSerializer 实现了 Serializer）
        if (ch instanceof Serializer) {
            return (Serializer) ch;
        }

        // 如果是我们自己定义的 SerialContext
        if (ch instanceof SerialContext) {
            return ((SerialContext) ch).serializer;
        }

        // 如果是 SAX 包装器 XMLFilterImpl（或子类），递归取里面的 handler
        if (ch instanceof org.xml.sax.helpers.XMLFilterImpl) {
            return getSerializerFromContentHandler(
                    ((org.xml.sax.helpers.XMLFilterImpl) ch).getContentHandler()
            );
        }

        // 一些自定义包装类可能也持有内部 handler
        // 如果它实现了一个 getContentHandler() 方法，则尝试通过反射访问
        try {
            java.lang.reflect.Method m = ch.getClass().getMethod("getContentHandler");
            if (ContentHandler.class.isAssignableFrom(m.getReturnType())) {
                ContentHandler inner = (ContentHandler) m.invoke(ch);
                return getSerializerFromContentHandler(inner);
            }
        } catch (NoSuchMethodException e) {
            // 没有这个方法，忽略
        } catch (Exception e) {
            throw new UIMARuntimeException(e);
        }

        // 如果还没找到，就抛异常
        throw new UIMARuntimeException(
                new IllegalArgumentException("Cannot locate Serializer inside ContentHandler of type: "
                        + ch.getClass().getName()));
    }
    // ====== 其余 XML 读写 / clone / equals 全部按原版保留 =====
    // ... 这里对应你发的原版全部复制，除 Introspector 相关外不改动 ...
    /** @deprecated */
    @Deprecated
    public List<NameClassPair> listAttributes() {
        try {
            List<NameClassPair> resultList = new ArrayList<>();
            for (MetaDataAttr attr : getAttributes()) {
                if (attr.reader != null && attr.writer != null) {
                    resultList.add(new NameClassPair(attr.name, attr.clazz.getName()));
                }
            }
            return resultList;
        } catch (Exception e) {
            throw new UIMARuntimeException(e);
        }
    }

    private Object getAttributeValue(MetaDataAttr attr) {
        Method reader = attr.reader;
        if (reader != null) {
            try {
                return reader.invoke(this);
            } catch (Exception e) {
                throw new UIMARuntimeException(e);
            }
        } else {
            return null;
        }
    }

    public Class getAttributeClass(String aName) {
        for (MetaDataAttr attr : getAttributes()) {
            if (attr.name.equals(aName)) return attr.clazz;
        }
        return null;
    }

    public boolean isModifiable() { return true; }

    private void setAttributeValue(MetaDataAttr attr, Object aValue) {
        Method writer = attr.writer;
        if (writer != null) {
            try {
                writer.invoke(this, aValue);
            } catch (IllegalArgumentException e) {
                throw new UIMA_IllegalArgumentException("metadata_attribute_type_mismatch", new Object[]{aValue, attr.name}, e);
            } catch (Exception e) {
                throw new UIMARuntimeException(e);
            }
        }
    }

    public URL getRelativePathBase() {
        if (mSourceUrl != null) return mSourceUrl;
        try {
            return new File(System.getProperty("user.dir")).toURL();
        } catch (MalformedURLException var4) {
            try {
                return new URL("file:/");
            } catch (MalformedURLException var3) {
                return null;
            }
        }
    }

    public URL getSourceUrl() { return this.mSourceUrl; }
    public String getSourceUrlString() { return mSourceUrl != null ? mSourceUrl.toString() : "<unknown>"; }

    public void setSourceUrlIfNull(URL aUrl) {
        if (this.mSourceUrl == null) this.setSourceUrl(aUrl);
    }

    public void setSourceUrl(URL aUrl) {
        this.mSourceUrl = aUrl;
        for (MetaDataAttr attr : getAttributes()) {
            Object val = getAttributeValue(attr);
            if (val instanceof MetaDataObject_impl) {
                ((MetaDataObject_impl) val).setSourceUrl(aUrl);
            } else if (val != null && val.getClass().isArray()) {
                for (Object item : (Object[]) val) {
                    if (item instanceof MetaDataObject_impl) {
                        ((MetaDataObject_impl) item).setSourceUrl(aUrl);
                    }
                }
            } else if (val instanceof Map) {
                for (Object value : ((Map) val).values()) {
                    if (value instanceof MetaDataObject_impl) {
                        ((MetaDataObject_impl) value).setSourceUrl(aUrl);
                    }
                }
            }else if (val instanceof List) { // 补充 List 类型的 URL 递归设置
                for (Object item : ((List<?>) val)) {
                    if (item instanceof MetaDataObject_impl) {
                        ((MetaDataObject_impl) item).setSourceUrl(aUrl);
                    }
                }
            }
        }
    }

    public Object clone() {
        try {
            MetaDataObject_impl clone = (MetaDataObject_impl) super.clone();
            for (MetaDataAttr attr : getAttributes()) {
                Object val = getAttributeValue(attr);
                if (val instanceof MetaDataObject) {
                    Object clonedVal = ((MetaDataObject) val).clone();
                    clone.setAttributeValue(attr, clonedVal);
                } else if (val != null && val.getClass().isArray()) {
                    Class componentType = val.getClass().getComponentType();
                    int length = Array.getLength(val);
                    Object arrayClone = Array.newInstance(componentType, length);
                    for (int j = 0; j < length; ++j) {
                        Object component = Array.get(val, j);
                        if (component instanceof MetaDataObject) {
                            component = ((MetaDataObject) component).clone();
                        }
                        Array.set(arrayClone, j, component);
                    }
                    clone.setAttributeValue(attr, arrayClone);
                }
            }
            return clone;
        } catch (CloneNotSupportedException e) {
            throw new UIMARuntimeException(e);
        }
    }

    public String toString() {
        StringBuilder buf = new StringBuilder();
        buf.append(getClass().getName()).append(": \n");
        for (MetaDataAttr attr : getAttributes()) {
            buf.append(attr.name).append(" = ");
            Object val = getAttributeValue(attr);
            if (val == null) {
                buf.append("NULL");
            } else if (!(val instanceof Object[])) {
                buf.append(val.toString());
            } else {
                Object[] array = (Object[]) val;
                buf.append("Array{");
                for (int j = 0; j < array.length; ++j) {
                    buf.append(j).append(": ").append(array[j].toString()).append('\n');
                }
                buf.append("}\n");
            }
            buf.append('\n');
        }
        return buf.toString();
    }

    public boolean equals(Object aObj) {
        if (!(aObj instanceof MetaDataObject_impl)) return false;
        MetaDataObject_impl mdo = (MetaDataObject_impl) aObj;
        MetaDataAttr[] theseAttrs = getAttributes();
        MetaDataAttr[] thoseAttrs = mdo.getAttributes();
        if (theseAttrs.length != thoseAttrs.length) return false;
        List<MetaDataAttr> thoseAttrsAsList = Arrays.asList(thoseAttrs);
        for (MetaDataAttr attr : theseAttrs) {
            if (!thoseAttrsAsList.contains(attr)) return false;
            Object val1 = getAttributeValue(attr);
            Object val2 = mdo.getAttributeValue(attr);
            if (!valuesEqual(val1, val2)) return false;
        }
        return true;
    }

    private boolean valuesEqual(Object val1, Object val2) {
        if (val1 == null) return val2 == null;
        if (val1.getClass().isArray()) {
            if (val2.getClass() != val1.getClass()) return false;
            if (val1 instanceof String[]) return Arrays.equals((String[]) val1, (String[]) val2);
            if (val1 instanceof Object[]) return Arrays.deepEquals((Object[]) val1, (Object[]) val2);
            if (val1 instanceof int[]) return Arrays.equals((int[]) val1, (int[]) val2);
            if (val1 instanceof float[]) return Arrays.equals((float[]) val1, (float[]) val2);
            if (val1 instanceof double[]) return Arrays.equals((double[]) val1, (double[]) val2);
            if (val1 instanceof boolean[]) return Arrays.equals((boolean[]) val1, (boolean[]) val2);
            if (val1 instanceof byte[]) return Arrays.equals((byte[]) val1, (byte[]) val2);
            if (val1 instanceof short[]) return Arrays.equals((short[]) val1, (short[]) val2);
            if (val1 instanceof long[]) return Arrays.equals((long[]) val1, (long[]) val2);
            return Arrays.equals((char[]) val1, (char[]) val2);
        } else if (val1 instanceof Map) {
            if (!(val2 instanceof Map)) return false;
            Map m1 = (Map) val1;
            Map m2 = (Map) val2;
            if (m1.size() != m2.size()) return false;
            if (val1.getClass() != val2.getClass()) return false;
            for (Object key : m1.keySet()) {
                if (!valuesEqual(m1.get(key), m2.get(key))) return false;
            }
            return true;
        } else {
            return val1.equals(val2);
        }
    }

    public int hashCode() {
        int hashCode = 0;
        for (MetaDataAttr attr : getAttributes()) {
            Object val = getAttributeValue(attr);
            if (val != null) {
                if (val instanceof Object[]) {
                    hashCode += Arrays.hashCode((Object[]) val);
                } else if (val instanceof Map) {
                    for (Object entryObj : ((Map) val).entrySet()) {
                        Map.Entry entry = (Map.Entry) entryObj;
                        hashCode += entry.getKey().hashCode();
                        Object subval = entry.getValue();
                        if (subval instanceof Object[]) {
                            hashCode += Arrays.hashCode((Object[]) subval);
                        } else {
                            hashCode += subval.hashCode();
                        }
                    }
                } else {
                    hashCode += val.hashCode();
                }
            }
        }
        return hashCode;
    }
    // 包含 MetaDataAttr 内部类、SerialContext、Serializer 接口等定义
    // ===== MetaDataAttr 内部类 =====
    public static class MetaDataAttr {
        final String name;
        final Method reader;
        final Method writer;
        final Class<?> clazz;

        public MetaDataAttr(String name, Method reader, Method writer, Class<?> clazz) {
            this.name = name;
            this.reader = reader;
            this.writer = writer;
            this.clazz = clazz;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof MetaDataAttr)) return false;
            MetaDataAttr other = (MetaDataAttr) obj;
            return Objects.equals(this.name, other.name) &&
                    Objects.equals(this.clazz, other.clazz);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name, clazz);
        }
    }

    public static class SerialContext {
        public final ContentHandler ch;
        public final Serializer serializer;
        public SerialContext(ContentHandler ch, Serializer serializer) {
            this.ch = ch;
            this.serializer = serializer;
        }
    }

    public interface Serializer {
        void outputStartElement(Node n, String ns, String ln, String qn, Attributes atts) throws SAXException;
        void outputEndElement(Node n, String ns, String ln, String qn) throws SAXException;
        void outputStartElementForArrayElement(Node n, String ns, String ln, String qn, Attributes atts) throws SAXException;
        void outputEndElementForArrayElement(Node n, String ns, String ln, String qn) throws SAXException;
        void insertNl();
        boolean shouldBeSkipped(PropertyXmlInfo i, Object v, MetaDataObject_impl obj);
        boolean startElementProperty();
        void deleteNodeStore();
        boolean indentChildElements(XmlizationInfo info, MetaDataObject_impl obj);
        void saveAndAddNodeStore(Node n);
        void addNodeStore();
        void writeDelayedStart(String name) throws SAXException;
        void writeSimpleValue(Object val) throws SAXException;
        void writeSimpleValueWithTag(String tag, Object val, Node node) throws SAXException;
        boolean shouldEncloseInArrayElement(Class<?> clazz);
        boolean isArrayHasIndentableElements(Object array);
        void maybeStartArraySymbol() throws SAXException;
        void maybeEndArraySymbol() throws SAXException;
        Node findMatchingSubElement(String name);
    }

    public static class XmlizationInfo {
        public final String xmlElementName;
        public final String xmlNamespace;
        public final PropertyXmlInfo[] propertyInfo;

        public XmlizationInfo(String aXmlElementName, String aXmlNamespace, PropertyXmlInfo[] aPropertyInfo) {
            this.xmlElementName = aXmlElementName;
            this.xmlNamespace = aXmlNamespace;
            this.propertyInfo = aPropertyInfo;
        }
    }

    public static class PropertyXmlInfo {
        public final String xmlElementName;
        public final boolean multiValued;
        public final boolean referencesAllowedValues;
        public final boolean isMandatory;
        public final boolean allowEmpty;
        public final Class<? extends MetaDataObject_impl> xmlizationClass;
        // 1. 泛型参数补全
        private static final transient ConcurrentHashMapWithProducer<Class<? extends MetaDataObject_impl>, MetaDataAttr[]> class2attrsMap
                = new ConcurrentHashMapWithProducer<>();
        private static final transient ConcurrentHashMapWithProducer<Class<? extends MetaDataObject_impl>, MetaDataAttr[]> class2attrsMapUnfiltered
                = new ConcurrentHashMapWithProducer<>();
        public PropertyXmlInfo(String aXmlElementName,
                               boolean aMultiValued,
                               Class<? extends MetaDataObject_impl> aXmlizationClass) {
            this(aXmlElementName, aMultiValued, false, false, true, aXmlizationClass);
        }

        public PropertyXmlInfo(String aXmlElementName,
                               boolean aMultiValued,
                               boolean aReferencesAllowedValues,
                               boolean aIsMandatory,
                               boolean aAllowEmpty,
                               Class<? extends MetaDataObject_impl> aXmlizationClass) {
            this.xmlElementName = aXmlElementName;
            this.multiValued = aMultiValued;
            this.referencesAllowedValues = aReferencesAllowedValues;
            this.isMandatory = aIsMandatory;
            this.allowEmpty = aAllowEmpty;
            this.xmlizationClass = aXmlizationClass;
        }
    }

    /**
     * Concrete subclasses must provide XMLizationInfo for serialization.
     */
    protected abstract XmlizationInfo getXmlizationInfo();

    // 2. XMLSerializer 构造器改成单参（或匹配当前API）
    public void toXML(OutputStream aStream) throws SAXException, IOException {
        toXML(new XMLSerializer(aStream).getContentHandler(), true);
    }

    public void toXML(Writer aWriter) throws SAXException, IOException {
        toXML(new XMLSerializer(aWriter).getContentHandler(), true);
    }
    public void toXML(ContentHandler aContentHandler, boolean aWriteDefaultNamespaceAttribute)
            throws SAXException {
        XmlizationInfo info = getXmlizationInfo();
        String nsUri = info.xmlNamespace == null ? "" : info.xmlNamespace;
        String qName = info.xmlElementName;
        aContentHandler.startElement(nsUri, info.xmlElementName, qName, EMPTY_ATTRIBUTES);

        for (MetaDataAttr attr : getAttributes()) {
            Object value = getAttributeValue(attr);
            if (value == null) continue;

            PropertyXmlInfo propInfo = null;
            for (PropertyXmlInfo pi : info.propertyInfo) {
                if (attr.name.equals(pi.xmlElementName)) {
                    propInfo = pi;
                    break;
                }
            }

            if (propInfo != null) {
                if (propInfo.multiValued && value.getClass().isArray()) {
                    Object[] array = (Object[]) value;
                    for (Object elem : array) {
                        if (elem instanceof MetaDataObject) {
                            ((MetaDataObject) elem).toXML(aContentHandler, true);
                        } else {
                            aContentHandler.startElement(nsUri, propInfo.xmlElementName, propInfo.xmlElementName, EMPTY_ATTRIBUTES);
                            aContentHandler.characters(elem.toString().toCharArray(), 0, elem.toString().length());
                            aContentHandler.endElement(nsUri, propInfo.xmlElementName, propInfo.xmlElementName);
                        }
                    }
                } else if (value instanceof MetaDataObject) {
                    ((MetaDataObject) value).toXML(aContentHandler, true);
                } else {
                    aContentHandler.startElement(nsUri, propInfo.xmlElementName, propInfo.xmlElementName, EMPTY_ATTRIBUTES);
                    String s = value.toString();
                    aContentHandler.characters(s.toCharArray(), 0, s.length());
                    aContentHandler.endElement(nsUri, propInfo.xmlElementName, propInfo.xmlElementName);
                }
            }
        }

        aContentHandler.endElement(nsUri, info.xmlElementName, info.xmlElementName);
    }

    public void buildFromXMLElement(Element aElement, XMLParser aParser, boolean aLenient)
            throws InvalidXMLException {
        XmlizationInfo info = getXmlizationInfo();
        NodeList childNodes = aElement.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node child = childNodes.item(i);
            if (child.getNodeType() == Node.ELEMENT_NODE) {
                String childName = child.getLocalName();
                for (PropertyXmlInfo propInfo : info.propertyInfo) {
                    if (propInfo.xmlElementName.equals(childName)) {
                        if (propInfo.multiValued) {
                            List<Object> values = new ArrayList<>();
                            NodeList arrayElems = child.getChildNodes();
                            for (int j = 0; j < arrayElems.getLength(); j++) {
                                Node elemNode = arrayElems.item(j);
                                if (elemNode.getNodeType() == Node.ELEMENT_NODE) {
                                    buildAndAdd((Element) elemNode, propInfo, aParser, values, aLenient);
                                }
                            }
                            setAttributeValue(propInfo.xmlElementName, values.toArray());
                        } else {
                            Object value = buildObjectFromElement((Element) child, propInfo, aParser, aLenient);
                            setAttributeValue(propInfo.xmlElementName, value);
                        }
                    }
                }
            }
        }
    }

    private void buildAndAdd(Element elem, PropertyXmlInfo propInfo, XMLParser parser,
                             List<Object> list, boolean lenient) throws InvalidXMLException {
        Object obj = buildObjectFromElement(elem, propInfo, parser, lenient);
        list.add(obj);
    }

    private Object buildObjectFromElement(Element elem, PropertyXmlInfo propInfo,
                                          XMLParser parser, boolean lenient) throws InvalidXMLException {
        if (MetaDataObject_impl.class.isAssignableFrom(propInfo.xmlizationClass)) {
            try {
                MetaDataObject_impl instance = propInfo.xmlizationClass.getDeclaredConstructor().newInstance();
                instance.buildFromXMLElement(elem, parser, lenient);
                return instance;
            } catch (Exception e) {
                throw new InvalidXMLException(e);
            }
        } else {
            return XMLUtils.getText(elem);
        }
    }
}