package org.apache.uima.resource.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.uima.UIMAFramework;
import org.apache.uima.UIMA_IllegalStateException;
import org.apache.uima.resource.CasManager;
import org.apache.uima.resource.DataResource;
import org.apache.uima.resource.ExternalResourceDependency;
import org.apache.uima.resource.ExternalResourceDescription;
import org.apache.uima.resource.FileResourceSpecifier;
import org.apache.uima.resource.ParameterizedDataResource;
import org.apache.uima.resource.RelativePathResolver;
import org.apache.uima.resource.Resource;
import org.apache.uima.resource.ResourceAccessException;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceManager;
import org.apache.uima.resource.SharedResourceObject;
import org.apache.uima.resource.metadata.ExternalResourceBinding;
import org.apache.uima.resource.metadata.ResourceManagerConfiguration;
import org.apache.uima.util.Level;
import org.apache.uima.util.XMLizable;

public class ResourceManager_impl implements ResourceManager {

    // 保留原常量和字段
    protected static final String LOG_RESOURCE_BUNDLE = "org.apache.uima.impl.log_messages";
    protected static final Class<? extends Resource> EMPTY_RESOURCE_CLASS = Resource.class;
    private final Object casManagerMonitor = new Object();
    private final RelativePathResolver mRelativePathResolver;

    protected final Map<String, Object> mResourceMap;
    protected final Map<String, ResourceRegistration> mInternalResourceRegistrationMap;
    protected final Map<String, Class<?>> mParameterizedResourceImplClassMap;
    protected final Map<String, Class<?>> mInternalParameterizedResourceImplClassMap;
    protected final Map<List<Object>, Object> mParameterizedResourceInstanceMap;

    // Android: 不使用 UIMAClassLoader，自定义 ClassLoader
    private volatile ClassLoader extensionClassLoader = null;

    protected volatile CasManager mCasManager = null;
    private final Map<String, XMLizable> importCache = Collections.synchronizedMap(new HashMap<>());

    public ResourceManager_impl() {
        this.mResourceMap = Collections.synchronizedMap(new HashMap<>());
        this.mInternalResourceRegistrationMap = new ConcurrentHashMap<>();
        this.mParameterizedResourceImplClassMap = new ConcurrentHashMap<>();
        this.mInternalParameterizedResourceImplClassMap = new ConcurrentHashMap<>();
        this.mParameterizedResourceInstanceMap = new ConcurrentHashMap<>();
        // Android：直接用默认实现
        this.mRelativePathResolver = new RelativePathResolver_impl();
    }

    public ResourceManager_impl(ClassLoader aClassLoader) {
        this();
        this.extensionClassLoader = aClassLoader;
        this.mRelativePathResolver.setPathResolverClassLoader(aClassLoader);
    }

    // ========= ClassLoader管理 =========
    @Override
    public synchronized void setExtensionClassPath(String classpath, boolean resolveResource) {
        // Android: 不动态新建URLClassLoader
        if (resolveResource) {
            try {
                this.mRelativePathResolver.setDataPath(classpath);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public synchronized void setExtensionClassPath(ClassLoader parent, String classpath, boolean resolveResource) {
        // Android: 不改变 parent loader
        this.extensionClassLoader = parent;
        if (resolveResource) {
            try {
                this.mRelativePathResolver.setDataPath(classpath);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public ClassLoader getExtensionClassLoader() {
        // Android: 返回已有的，默认线程ClassLoader
        return extensionClassLoader != null ? extensionClassLoader : Thread.currentThread().getContextClassLoader();
    }

    // ========= DataPath & 路径解析 =========
    @Override
    public String getDataPath() {
        return this.mRelativePathResolver.getDataPath();
    }

    @Override
    public void setDataPath(String aPath) throws MalformedURLException {
        this.mRelativePathResolver.setDataPath(aPath);
    }

    @Override
    public URL resolveRelativePath(String aRelativePath) throws MalformedURLException {
        URL relativeUrl;
        try {
            relativeUrl = new URL(aRelativePath);
        } catch (MalformedURLException e) {
            relativeUrl = new URL("file", "", aRelativePath);
        }
        return this.mRelativePathResolver.resolveRelativePath(relativeUrl);
    }

    // ========= 资源获取 =========
    @Override
    public Object getResource(String aName) throws ResourceAccessException {
        Object r = this.mResourceMap.get(aName);
        if (r instanceof ParameterizedDataResource) {
            throw new ResourceAccessException("parameters_required", new Object[]{aName});
        } else {
            return r;
        }
    }

    @Override
    public Object getResource(String aName, String[] aParams) throws ResourceAccessException {
        Object r = this.mResourceMap.get(aName);
        if (r == null) {
            return null;
        } else if (!(r instanceof ParameterizedDataResource)) {
            throw new ResourceAccessException("parameters_not_allowed", new Object[]{aName});
        } else {
            ParameterizedDataResource pdr = (ParameterizedDataResource) r;
            DataResource dr;
            try {
                dr = pdr.getDataResource(aParams);
            } catch (ResourceInitializationException e) {
                throw new ResourceAccessException(e);
            }

            List<Object> key = new ArrayList<>(2);
            key.add(aName);
            key.add(dr);
            Object instance = this.mParameterizedResourceInstanceMap.get(key);
            if (instance != null) {
                return instance;
            }
            synchronized (this.mParameterizedResourceInstanceMap) {
                instance = this.mParameterizedResourceInstanceMap.get(key);
                if (instance != null) {
                    return instance;
                }
                Class<?> implClass = this.mParameterizedResourceImplClassMap.get(aName);
                if (implClass != EMPTY_RESOURCE_CLASS) {
                    try {
                        SharedResourceObject sro = (SharedResourceObject) implClass.newInstance();
                        sro.load(dr);
                        this.mParameterizedResourceInstanceMap.put(key, sro);
                        return sro;
                    } catch (Exception e) {
                        throw new ResourceAccessException(e);
                    }
                } else {
                    this.mParameterizedResourceInstanceMap.put(key, dr);
                    return dr;
                }
            }
        }
    }

    @SuppressWarnings("unchecked") // 保证在Android上编译通过，屏蔽泛型转换警告
    public Class<? extends Resource> getResourceClass(String aName) {
        Object r = this.mResourceMap.get(aName);
        if (r == null) {
            return null;
        } else if (r instanceof ParameterizedDataResource) {
            // 泛型擦除再强制转换，保持与原UIMA一致
            Class<? extends Resource> customResourceClass =
                    (Class<? extends Resource>) (Class<?>) this.mParameterizedResourceImplClassMap.get(aName);

            // 如果没有指定具体的实现类，则返回默认的 DataResource_impl
            if (customResourceClass == EMPTY_RESOURCE_CLASS) {
                return (Class<? extends Resource>) DataResource_impl.class; // 显式类型转换，兼容Android编译器
            } else {
                return customResourceClass;
            }
        } else {
            // 直接返回对象的 Class，但要强转成 Class<? extends Resource> 才能满足方法返回类型
            return (Class<? extends Resource>) r.getClass();
        }
    }
    @Override
    public InputStream getResourceAsStream(String aKey) throws ResourceAccessException {
        return getResourceAsStreamCommon(getResource(aKey));
    }

    @Override
    public InputStream getResourceAsStream(String aKey, String[] aParams) throws ResourceAccessException {
        return getResourceAsStreamCommon(getResource(aKey, aParams));
    }

    private InputStream getResourceAsStreamCommon(Object resource) throws ResourceAccessException {
        try {
            return (resource instanceof DataResource) ? ((DataResource) resource).getInputStream() : null;
        } catch (IOException e) {
            throw new ResourceAccessException(e);
        }
    }

    @Override
    public URL getResourceURL(String aKey) throws ResourceAccessException {
        return getResourceUrlCommon(getResource(aKey));
    }

    @Override
    public URL getResourceURL(String aKey, String[] aParams) throws ResourceAccessException {
        return getResourceUrlCommon(getResource(aKey, aParams));
    }

    private URL getResourceUrlCommon(Object resource) {
        return (resource instanceof DataResource) ? ((DataResource) resource).getUrl() : null;
    }

    // ========= 外部资源初始化 =========
    @Override
    public synchronized void initializeExternalResources(ResourceManagerConfiguration cfg,
                                                         String contextName,
                                                         Map<String, Object> additionalParams)
            throws ResourceInitializationException {
        ExternalResourceDescription[] resources = cfg.getExternalResources();
        for (ExternalResourceDescription res : resources) {
            String name = res.getName();
            ResourceRegistration reg = this.mInternalResourceRegistrationMap.get(name);
            if (reg == null) {
                registerResource(name, res, contextName, additionalParams);
            } else if (!reg.description.equals(res)) {
                if (contextName.startsWith(reg.definingContext)) {
                    UIMAFramework.getLogger().logrb(Level.CONFIG, getClass().getName(),
                            "initializeExternalResources", LOG_RESOURCE_BUNDLE,
                            "UIMA_overridden_resource__CONFIG",
                            new Object[]{name, contextName, reg.definingContext});
                } else {
                    UIMAFramework.getLogger().logrb(Level.WARNING, getClass().getName(),
                            "initializeExternalResources", LOG_RESOURCE_BUNDLE,
                            "UIMA_duplicate_resource_name__WARNING",
                            new Object[]{name, reg.definingContext, contextName});
                }
            }
        }

        ExternalResourceBinding[] bindings = cfg.getExternalResourceBindings();
        for (ExternalResourceBinding b : bindings) {
            ResourceRegistration reg = this.mInternalResourceRegistrationMap.get(b.getResourceName());
            if (reg == null) {
                throw new ResourceInitializationException("unknown_resource_name",
                        new Object[]{b.getResourceName(), b.getSourceUrlString()});
            }
            this.mResourceMap.put(contextName + b.getKey(), reg.resource);
            Class<?> impl = this.mInternalParameterizedResourceImplClassMap.get(b.getResourceName());
            this.mParameterizedResourceImplClassMap.put(contextName + b.getKey(),
                    (impl == null) ? EMPTY_RESOURCE_CLASS : impl);
        }
    }

    @Override
    public synchronized void resolveAndValidateResourceDependencies(ExternalResourceDependency[] deps,
                                                                    String contextName)
            throws ResourceInitializationException {
        for (ExternalResourceDependency dep : deps) {
            String qname = contextName + dep.getKey();
            Object resource = this.mResourceMap.get(qname);
            if (resource == null) {
                try {
                    URL relativeUrl = new URL("file", "", dep.getKey());
                    URL absUrl = this.mRelativePathResolver.resolveRelativePath(relativeUrl);
                    if (absUrl != null) {
                        FileResourceSpecifier spec = new FileResourceSpecifier_impl();
                        spec.setFileUrl(absUrl.toString());
                        resource = UIMAFramework.produceResource(spec, null);
                        this.mResourceMap.put(qname, resource);
                    }
                } catch (MalformedURLException e) {
                    throw new ResourceInitializationException(e);
                }
            }
            if (resource == null && !dep.isOptional()) {
                throw new ResourceInitializationException("resource_dependency_not_satisfied",
                        new Object[]{dep.getKey(), dep.getSourceUrlString()});
            }
            // 校验接口
            if (resource != null && dep.getInterfaceName() != null && !dep.getInterfaceName().isEmpty()) {
                try {
                    Class<?> iface = (getExtensionClassLoader() != null)
                            ? getExtensionClassLoader().loadClass(dep.getInterfaceName())
                            : Class.forName(dep.getInterfaceName());
                    Class<? extends Resource> resourceClass = getResourceClass(qname);
                    if (!iface.isAssignableFrom(resourceClass)) {
                        throw new ResourceInitializationException("resource_does_not_implement_interface",
                                new Object[]{qname, dep.getInterfaceName(), dep.getSourceUrlString()});
                    }
                } catch (ClassNotFoundException e) {
                    throw new ResourceInitializationException("class_not_found",
                            new Object[]{dep.getInterfaceName(), dep.getSourceUrlString()});
                }
            }
        }
    }

    private void registerResource(String name, ExternalResourceDescription desc, String context,
                                  Map<String, Object> initParams) throws ResourceInitializationException {
        Map<String, Object> params = (initParams == null) ? new HashMap<>() : new HashMap<>(initParams);
        params.put("RELATIVE_PATH_RESOLVER", this.mRelativePathResolver);

        boolean verificationMode = params.containsKey("VERIFICATION_MODE");
        Object r = UIMAFramework.produceResource(desc.getResourceSpecifier(), params);

        String implName = desc.getImplementationName();
        Class<?> implClass = null;
        if (implName != null && !implName.isEmpty()) {
            try {
                if (getExtensionClassLoader() != null) {
                    implClass = getExtensionClassLoader().loadClass(implName);
                } else {
                    implClass = Class.forName(implName);
                }
                if (!SharedResourceObject.class.isAssignableFrom(implClass)) {
                    throw new ResourceInitializationException("not_a_shared_resource_object",
                            new Object[]{implName, desc.getSourceUrlString()});
                }
            } catch (ClassNotFoundException e) {
                throw new ResourceInitializationException("class_not_found",
                        new Object[]{implName, desc.getSourceUrlString()}, e);
            }
        }

        if (r instanceof DataResource) {
            if (implClass != null) {
                try {
                    SharedResourceObject sro = (SharedResourceObject) implClass.newInstance();
                    if (!verificationMode) sro.load((DataResource) r);
                    r = sro;
                } catch (Exception e) {
                    throw new ResourceInitializationException("could_not_instantiate",
                            new Object[]{implClass.getName(), desc.getSourceUrlString()}, e);
                }
            }
        } else if (r instanceof ParameterizedDataResource) {
            this.mInternalParameterizedResourceImplClassMap.put(name,
                    (implClass == null) ? EMPTY_RESOURCE_CLASS : implClass);
        } else if (implClass != null) {
            throw new ResourceInitializationException("not_a_data_resource",
                    new Object[]{implClass.getName(), name, r.getClass().getName(), desc.getSourceUrlString()});
        }
        this.mInternalResourceRegistrationMap.put(name, new ResourceRegistration(r, desc, context));
    }

    @Override
    public CasManager getCasManager() {
        if (this.mCasManager != null) return this.mCasManager;
        synchronized (this.casManagerMonitor) {
            if (this.mCasManager == null) {
                this.mCasManager = new CasManager_impl(this);
            }
            return this.mCasManager;
        }
    }

    @Override
    public void setCasManager(CasManager cm) {
        synchronized (this.casManagerMonitor) {
            if (this.mCasManager == null) {
                this.mCasManager = cm;
            } else {
                throw new UIMA_IllegalStateException("cannot_set_cas_manager", new Object[0]);
            }
        }
    }

    protected RelativePathResolver getRelativePathResolver() {
        return this.mRelativePathResolver;
    }

    @Override
    public Map<String, XMLizable> getImportCache() {
        return this.importCache;
    }

    protected static class ResourceRegistration {
        Object resource;
        ExternalResourceDescription description;
        String definingContext;
        ResourceRegistration(Object r, ExternalResourceDescription d, String c) {
            this.resource = r;
            this.description = d;
            this.definingContext = c;
        }
    }

}
