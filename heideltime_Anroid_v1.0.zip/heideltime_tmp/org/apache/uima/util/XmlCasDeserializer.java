package org.apache.uima.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.uima.cas.CAS;
import org.apache.uima.cas.impl.OutOfTypeSystemData;
import org.apache.uima.cas.impl.XCASDeserializer;
import org.apache.uima.cas.impl.XmiCasDeserializer;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public abstract class XmlCasDeserializer {

    public static void deserialize(InputStream aStream, CAS aCAS) throws SAXException, IOException {
        deserialize(aStream, aCAS, false);
    }

    public static void deserialize(InputStream aStream, CAS aCAS, boolean aLenient)
            throws SAXException, IOException {
        XMLReader xmlReader = createXMLReader();
        ContentHandler handler = new XmlCasDeserializerHandler(aCAS, aLenient);
        xmlReader.setContentHandler(handler);
        xmlReader.parse(new InputSource(aStream));
    }

    /** Android兼容XMLReader创建（避免XMLReaderFactory可能找不到实现） */
    private static XMLReader createXMLReader() throws SAXException {
        try {
            SAXParserFactory spf = SAXParserFactory.newInstance();
            spf.setNamespaceAware(true);
            SAXParser sp = spf.newSAXParser();
            return sp.getXMLReader();
        } catch (Exception e) {
            throw new SAXException("Cannot create XMLReader", e);
        }
    }

    static class XmlCasDeserializerHandler extends DefaultHandler {
        private final CAS mCAS;
        private final boolean mLenient;
        private ContentHandler mDelegateHandler;

        XmlCasDeserializerHandler(CAS cas, boolean lenient) {
            this.mCAS = cas;
            this.mLenient = lenient;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes)
                throws SAXException {
            if (this.mDelegateHandler == null) {
                String xmiVer = attributes.getValue("xmi:version");
                if (xmiVer != null && xmiVer.length() > 0) {
                    XmiCasDeserializer deser = new XmiCasDeserializer(this.mCAS.getTypeSystem());
                    this.mDelegateHandler = deser.getXmiCasHandler(this.mCAS, this.mLenient);
                } else if ("CAS".equals(localName)) {
                    XCASDeserializer deser = new XCASDeserializer(this.mCAS.getTypeSystem());
                    this.mDelegateHandler = deser.getXCASHandler(this.mCAS,
                            this.mLenient ? new OutOfTypeSystemData() : null);
                } else {
                    XmiCasDeserializer deser = new XmiCasDeserializer(this.mCAS.getTypeSystem());
                    this.mDelegateHandler = deser.getXmiCasHandler(this.mCAS, this.mLenient);
                }
                this.mDelegateHandler.startDocument();
            }
            this.mDelegateHandler.startElement(uri, localName, qName, attributes);
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            this.mDelegateHandler.characters(ch, start, length);
        }

        @Override
        public void endDocument() throws SAXException {
            this.mDelegateHandler.endDocument();
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            this.mDelegateHandler.endElement(uri, localName, qName);
        }

        @Override
        public void error(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void fatalError(SAXParseException e) throws SAXException {
            throw e;
        }

        @Override
        public void warning(SAXParseException e) throws SAXException {
            throw e;
        }
    }
}