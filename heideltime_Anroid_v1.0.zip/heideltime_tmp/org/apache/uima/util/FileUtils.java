package org.apache.uima.util;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Random;

public class FileUtils {

    public static ArrayList<File> getFiles(File directory, boolean recursive) {
        ArrayList<File> fileList = new ArrayList<>();
        if (directory.exists() && directory.isDirectory()) {
            for (File file : directory.listFiles()) {
                if (file.isDirectory() && recursive) {
                    fileList.addAll(getFiles(file, true));
                } else if (file.isFile()) {
                    fileList.add(file);
                }
            }
        }
        return fileList;
    }

    public static ArrayList<File> getFiles(File directory) {
        return getFiles(directory, false);
    }

    public static ArrayList<File> getSubDirs(File directory) {
        ArrayList<File> dirList = new ArrayList<>();
        if (directory.exists() && directory.isDirectory()) {
            for (File file : directory.listFiles()) {
                if (file.isDirectory()) {
                    dirList.add(file);
                }
            }
        }
        return dirList;
    }

    public static String reader2String(Reader reader) throws IOException {
        try (Reader r = reader) {
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[4096];
            int len;
            while ((len = r.read(buf)) != -1) {
                sb.append(buf, 0, len);
            }
            return sb.toString();
        }
    }

    public static String file2String(File file) throws IOException {
        return reader2String(new FileReader(file));
    }

    public static String file2String(File file, String encoding) throws IOException {
        if (encoding == null) return file2String(file);
        return reader2String(new InputStreamReader(new FileInputStream(file), encoding));
    }

    public static void saveString2File(String content, File file) throws IOException {
        saveString2File(content, file, Charset.defaultCharset().name());
    }

    public static void saveString2File(String content, File file, String encoding) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), encoding))) {
            writer.write(content);
        }
    }

    public static void deleteAllFiles(File directory) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isFile()) {
                    f.delete();
                }
            }
        }
    }

    public static boolean deleteRecursive(File file) {
        if (!file.exists()) return false;
        boolean rc = true;
        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                rc &= deleteRecursive(f);
            }
        }
        rc &= file.delete();
        return rc;
    }

    public static boolean mkdir(File directory) {
        return !directory.exists() && directory.mkdir();
    }

    public static File createTempDir(File parent, String prefix) {
        Random rand = new Random();
        File tempDir;
        do {
            tempDir = new File(parent, prefix + rand.nextInt());
        } while (tempDir.exists());

        if (tempDir.mkdirs()) {
            // Android: skip deleteOnExit(), manual cleanup required
            return tempDir;
        }
        return null;
    }

    public static File createTempFile(String prefix, String suffix, File tempDir) throws IOException {
        File file = File.createTempFile(prefix, suffix, tempDir);
        // Android: skip deleteOnExit(), manual cleanup required
        return file;
    }

    public static void copyFile(File file, File dir) throws IOException {
        if (!file.exists() || !file.canRead()) {
            throw new IOException("File does not exist or is not readable: " + file.getAbsolutePath());
        }
        if (!dir.exists() || !dir.isDirectory()) {
            throw new IOException("Destination does not exist or is not a directory: " + dir.getAbsolutePath());
        }
        File outFile = new File(dir, file.getName());
        if (outFile.exists() && !outFile.canWrite()) {
            throw new IOException("Can't write output file: " + outFile);
        }

        try (InputStream is = new FileInputStream(file);
             OutputStream os = new FileOutputStream(outFile)) {
            byte[] buffer = new byte[8192]; // smaller buffer to save RAM
            int len;
            while ((len = is.read(buffer)) != -1) {
                os.write(buffer, 0, len);
            }
        }
    }

    public static String findRelativePath(File file, File relativeToDir) throws IOException {
        String[] filePath = getPathComponents(file.getCanonicalPath());
        String[] basePath = getPathComponents(relativeToDir.getCanonicalPath());

        int i = 0;
        while (i < filePath.length && i < basePath.length && filePath[i].equals(basePath[i])) {
            i++;
        }
        StringBuilder sb = new StringBuilder();
        for (int j = i; j < basePath.length; j++) sb.append("../");
        for (int j = i; j < filePath.length - 1; j++) sb.append(filePath[j]).append('/');
        sb.append(filePath[filePath.length - 1]);
        return sb.toString();
    }

    public static String[] getPathComponents(String canonicalPath) {
        String regex = File.separator;
        if ("\\".equals(regex)) regex = "\\\\";
        return canonicalPath.split(regex);
    }
}