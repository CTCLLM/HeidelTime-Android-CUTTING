package org.apache.uima.util;

import org.apache.uima.cas.CAS;
import org.apache.uima.cas.TypeSystem;
import org.apache.uima.cas.impl.XmiCasSerializer;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.OutputStream;

public abstract class XmlCasSerializer {

    /** 序列化 CAS 到 XMI（使用 CAS 自身类型系统） */
    public static void serialize(CAS aCAS, OutputStream aStream)
            throws SAXException, IOException {
        XmiCasSerializer.serialize(aCAS, aStream);
    }

    /** 序列化 CAS 到 XMI，按目标类型系统截断或转换 */
    public static void serialize(CAS aCAS, TypeSystem aTargetTypeSystem, OutputStream aStream)
            throws SAXException, IOException {
        XmiCasSerializer.serialize(aCAS, aTargetTypeSystem, aStream);
    }

    public static void serialize(CAS aCAS, OutputStream aStream, String encoding)
            throws SAXException, IOException {
        XmiCasSerializer serializer = new XmiCasSerializer(aCAS.getTypeSystem());
        serializer.serialize(aCAS, aStream); // 直接调用可用的 API
    }
}