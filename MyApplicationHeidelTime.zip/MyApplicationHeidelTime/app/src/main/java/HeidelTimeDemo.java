import org.apache.uima.jcas.JCas;

import de.unihd.dbs.uima.annotator.heideltime.HeidelTime;
import de.unihd.dbs.uima.annotator.heideltime.HeidelTimeStandalone;
import de.unihd.dbs.uima.annotator.heideltime.resources.Language;
import de.unihd.dbs.uima.annotator.heideltime.resources.Options_Tokenizer;
import de.unihd.dbs.uima.annotator.heideltime.resources.Options_Types;

public class HeidelTimeDemo {

    public static void main(String[] args) throws Exception {
        // 配置参数
        Language language = Language.CHINESE; // 中文
        Options_Types type = Options_Types.NEWS; // 文本类型：新闻/叙述/小说
        Options_Tokenizer tokenizer = Options_Tokenizer.NONE; // 预分词输入时用 NONE

        String configPath = "config.props"; // 配置文件路径

        // 初始化 HeidelTime
        HeidelTimeStandalone heideltime = new HeidelTimeStandalone(
                language,
                type,
                tokenizer,
                configPath
        );

        // 要处理的中文文本（已按规则分好词，-pos no等价于NONE模式）
        String text = "我们 在 2024年 6月 5日 去 北京 开会 。";

        // 创建 UIMA CAS（内部数据结构）
        JCas jcas = heideltime.process(text);

        // 输出 TimeML 格式标注结果
        String timeml = HeidelTime.getTimeMLDocument(jcas);
        System.out.println("----- TimeML 输出 -----");
        System.out.println(timeml);
    }
}