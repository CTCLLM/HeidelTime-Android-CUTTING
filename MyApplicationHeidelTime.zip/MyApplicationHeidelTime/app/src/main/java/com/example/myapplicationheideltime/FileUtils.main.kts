#!/usr/bin/env kotlin
package com.example.myapplicationheideltime

import android.content.Context
import java.io.File
import java.io.FileOutputStream

object FileUtils {

    /**
     * 从 assets 复制文件/文件夹到私有目录
     */
    fun copyAssetsToDir(context: Context, assetPath: String, destDir: File) {
        val assetManager = context.assets
        val files = assetManager.list(assetPath) ?: return

        if (!destDir.exists()) destDir.mkdirs()

        files.forEach { name ->
            val path = if (assetPath.isEmpty()) name else "$assetPath/$name"
            val outFile = File(destDir, name)

            val subFiles = assetManager.list(path)
            if (subFiles.isNullOrEmpty()) {
                // 是文件
                assetManager.open(path).use { input ->
                    FileOutputStream(outFile).use { output ->
                        input.copyTo(output)
                    }
                }
            } else {
                // 是文件夹
                copyAssetsToDir(context, path, outFile)
            }
        }
    }

    /**
     * 准备 HeidelTime 运行环境
     */
    fun prepareHeidelTimeEnvironment(context: Context): File {
        // 1. 目标目录: /data/user/0/<包名>/files/heideltime
        val heidelDir = File(context.filesDir, "heideltime")
        if (!heidelDir.exists()) {
            heidelDir.mkdirs()
        }

        // 2. 复制整个 assets
        copyAssetsToDir(context, "", heidelDir)

        // 3. 替换 config.props 路径
        val configFile = File(heidelDir, "config.props")
        val text = configFile.readText()
        val newText = text
            .replace("./treetagger", File(heidelDir, "treetagger").absolutePath)
            .replace("\\", "/")
        configFile.writeText(newText)

        return configFile
    }
}
