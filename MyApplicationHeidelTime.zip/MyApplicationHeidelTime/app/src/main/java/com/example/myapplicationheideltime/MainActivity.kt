package com.example.myapplicationheideltime

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import java.io.File

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView: TextView = findViewById(R.id.tvResult)
        val button: Button = findViewById(R.id.button)

        button.setOnClickListener {
            Thread {
                try {
                    // 1. 准备 HeidelTime 配置文件和 TreeTagger
                    val configFile: File = FileUtils.prepareHeidelTimeEnvironment(this)

                    // 2. 设置 configFile System Property
                    System.setProperty("configFile", configFile.absolutePath)

                    // 3. 这里调用 HeidelTime（示例）
                    val outputFile = File(getExternalFilesDir(null), "output.xml")

                    HeidelTimeDirectCall.runHeidelTime(
                        "english", // 语言
                        "/sdcard/Download/test/heideltime-standalone/test_txt/test_en.txt", // 输入文本路径（注意：需要 READ 权限）
                        outputFile.absolutePath, // 输出文件
                        false, // 不启用文档创建时间(DCT)
                        "UTF-8" // 字符编码
                    )

                    // 4. UI 更新
                    runOnUiThread {
                        textView.text = "解析完成!\n配置文件: ${configFile.absolutePath}\n输出文件: ${outputFile.absolutePath}"
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    runOnUiThread {
                        Toast.makeText(this, "出错: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }.start()
        }
    }
}