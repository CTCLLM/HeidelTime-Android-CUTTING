import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class HeidelTimeDirectCall {

    /**
     * 显式调用 HeidelTime
     * @param language  "english" 或 "chinese"
     * @param inputPath 输入文件路径
     * @param outputPath 输出文件路径
     * @param verbose   是否开启 verbose
     * @param encoding  输出编码，比如 "UTF-8"
     */
    public static void runHeidelTime(String language,
                                     String inputPath,
                                     String outputPath,
                                     boolean verbose,
                                     String encoding) {
        try {
            // 设置全局文件编码，相当于命令行的 -Dfile.encoding=UTF-8
            if (encoding != null) {
                System.setProperty("file.encoding", encoding);
            }

            // 构造 HeidelTime 命令行参数
            // 原命令行: java -jar ... -l english -pos no -t news [-v] input
            // 这里用 args[] 调用 Main.main()
            if (verbose) {
                de.unihd.dbs.heideltime.standalone.Main.main(
                        new String[]{"-l", language, "-pos", "no", "-t", "news", "-v", inputPath}
                );
            } else {
                de.unihd.dbs.heideltime.standalone.Main.main(
                        new String[]{"-l", language, "-pos", "no", "-t", "news", inputPath}
                );
            }

            System.out.println("解析完成，结果已输出到: " + outputPath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {
        // 输出 XML 到文件（等价于 > output.xml）
        try (PrintStream out = new PrintStream(
                new FileOutputStream(new File("output.xml")),
                true,
                StandardCharsets.UTF_8)) {
            PrintStream oldOut = System.out;
            System.setOut(out);

            // 调用英文，不分词
            runHeidelTime("english", "./test_txt/test_en.txt", "output.xml", false, "UTF-8");

            // 还原输出流
            System.setOut(oldOut);
        }
    }
}